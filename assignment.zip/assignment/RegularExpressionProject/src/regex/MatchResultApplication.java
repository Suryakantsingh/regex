package regex;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.Path;
import javax.ws.rs.core.Application;
@ApplicationPath("rest")
public class MatchResultApplication extends Application {
    
	private Set<Object> singleton = new HashSet<>();
	
	public MatchResultApplication(){
		singleton.add(new MatchResult());
	}
	
	public Set<Object> getSingleton(){
		return singleton;
	}

}
