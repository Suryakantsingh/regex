package regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONObject;

@Path("/MatchResult")
public class MatchResult {
	
	@POST
	@Path("/search")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public String matchinResult(String input){
		try{
		
			JSONObject inputValue = new JSONObject(input);
			JSONObject result = new JSONObject();
		    String regex = inputValue.getString("regex");
		    String textBody = inputValue.getString("textBody");
		    
		    if(regex.charAt(0)=='.' && regex.charAt(1)=='*'){
		    	result.put("match", "");
		    	result.put("error", "true");
		    	return result.toString();
		    }else{
		    	
		    	Pattern pt = Pattern.compile(regex);

		        Matcher match  = pt.matcher(textBody);
		        
                String strMatch ="";
                boolean flag = false;
		        while(match.find()){
		            
		            strMatch = textBody.substring(match.start(),match.end());
		            flag = true;
		            break;
		        }
		        if(flag){
		        	result.put("match", strMatch );
		        	result.put("error", "false");
		        }else{
		        	result.put("match", "" );
		        	result.put("error", "false");
		        }
		        return result.toString();	
		    }
		    
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return "Success";
	}
}
